import React from 'react';
import { Heart, ShoppingCart } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Organic Apples',
    price: 4.99,
    unit: 'kg',
    rating: 4.8,
    reviews: 24,
    image: 'https://images.pexels.com/photos/1510392/pexels-photo-1510392.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    farmer: 'Green Valley Farm',
    location: 'California'
  },
  {
    id: 2,
    name: 'Fresh Carrots',
    price: 2.49,
    unit: 'bunch',
    rating: 4.6,
    reviews: 18,
    image: 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    farmer: 'Sunrise Organics',
    location: 'Oregon'
  },
  {
    id: 3,
    name: 'Heirloom Tomatoes',
    price: 5.99,
    unit: 'kg',
    rating: 4.9,
    reviews: 32,
    image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    farmer: 'Red Earth Farms',
    location: 'Florida'
  },
  {
    id: 4,
    name: 'Organic Honey',
    price: 12.99,
    unit: 'jar',
    rating: 5.0,
    reviews: 42,
    image: 'https://images.pexels.com/photos/1638280/pexels-photo-1638280.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    farmer: 'Bee Haven Apiaries',
    location: 'Vermont'
  },
  {
    id: 5,
    name: 'Fresh Spinach',
    price: 3.49,
    unit: 'bunch',
    rating: 4.7,
    reviews: 15,
    image: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    farmer: 'Green Leaf Farms',
    location: 'Washington'
  },
  {
    id: 6,
    name: 'Artisan Bread',
    price: 6.99,
    unit: 'loaf',
    rating: 4.8,
    reviews: 28,
    image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    farmer: 'Hearth & Mill Bakery',
    location: 'Maine'
  },
  {
    id: 7,
    name: 'Free-Range Eggs',
    price: 5.49,
    unit: 'dozen',
    rating: 4.9,
    reviews: 36,
    image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    farmer: 'Happy Hen Farm',
    location: 'Iowa'
  },
  {
    id: 8,
    name: 'Organic Blueberries',
    price: 7.99,
    unit: 'pint',
    rating: 4.7,
    reviews: 22,
    image: 'https://images.pexels.com/photos/1153655/pexels-photo-1153655.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    farmer: 'Berry Good Farms',
    location: 'Michigan'
  }
];

const FeaturedProducts = () => {
  return (
    <div className="bg-white py-12 sm:py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Featured Products
          </h2>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Discover the freshest picks from our local farmers
          </p>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
          {products.map((product) => (
            <div key={product.id} className="group relative bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="w-full min-h-80 aspect-w-1 aspect-h-1 rounded-t-lg overflow-hidden group-hover:opacity-75 lg:h-60 lg:aspect-none">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-center object-cover lg:w-full lg:h-full"
                />
                <button className="absolute top-2 right-2 p-1.5 rounded-full bg-white/80 hover:bg-white text-gray-600 hover:text-red-500 transition-colors">
                  <Heart className="h-5 w-5" />
                </button>
              </div>
              <div className="p-4">
                <div className="flex justify-between">
                  <h3 className="text-sm text-gray-500">
                    {product.farmer} • {product.location}
                  </h3>
                  <div className="flex items-center">
                    <svg className="h-4 w-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    <span className="ml-1 text-sm text-gray-500">{product.rating} ({product.reviews})</span>
                  </div>
                </div>
                <h3 className="mt-1 text-lg font-medium text-gray-900">
                  {product.name}
                </h3>
                <div className="mt-2 flex justify-between items-center">
                  <p className="text-xl font-semibold text-gray-900">
                    ${product.price}
                    <span className="text-sm text-gray-500 font-normal">/{product.unit}</span>
                  </p>
                  <button className="p-2 rounded-full bg-green-100 text-green-800 hover:bg-green-600 hover:text-white transition-colors">
                    <ShoppingCart className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <a
            href="#"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            View All Products
            <ArrowRight className="ml-2 h-5 w-5" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default FeaturedProducts;